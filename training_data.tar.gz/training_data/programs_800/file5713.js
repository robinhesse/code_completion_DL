define({
    name: 'beta'
});
