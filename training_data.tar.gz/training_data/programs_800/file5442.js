define({
	"button.addtoc.tooltip": "Inhaltsverzeichnis"
});
