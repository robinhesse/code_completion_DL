/*
YUI 3.15.0 (build 834026e)
Copyright 2014 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/

YUI.add("lang/datatype-date-format_tr",function(e){e.Intl.add("datatype-date-format","tr",{a:["Paz","Pzt","Sal","\u00c7ar","Per","Cum","Cmt"],A:["Pazar","Pazartesi","Sal\u0131","\u00c7ar\u015famba","Per\u015fembe","Cuma","Cumartesi"],b:["Oca","\u015eub","Mar","Nis","May","Haz","Tem","A\u011fu","Eyl","Eki","Kas","Ara"],B:["Ocak","\u015eubat","Mart","Nisan","May\u0131s","Haziran","Temmuz","A\u011fustos","Eyl\u00fcl","Ekim","Kas\u0131m","Aral\u0131k"],c:"%d %b %Y %a %H:%M:%S %Z",p:["AM","PM"],P:["am","pm"],x:"%d.%m.%Y",X:"%H:%M:%S"})},"3.15.0");
