/*

StructIO outro
==============

Copyright (c) 2011 The Parchment Contributors
BSD licenced
http://code.google.com/p/parchment

*/

;;; (function( window, $, undefined ){

// Expose
window.StructIO = StructIO;
StructIO.TextInput = TextInput;

})( window, jQuery );