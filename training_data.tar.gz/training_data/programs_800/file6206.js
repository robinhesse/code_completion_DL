'use strict';

/* jasmine specs for directives go here */

describe('directives', function() {
  beforeEach(module('bookingApp.directives'));
});
